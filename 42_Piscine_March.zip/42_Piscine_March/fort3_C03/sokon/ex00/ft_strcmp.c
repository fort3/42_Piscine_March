/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcmp.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sokon <sokon@student.42.fr>                #+#  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024-03-06 11:37:33 by sokon             #+#    #+#             */
/*   Updated: 2024-03-06 11:37:33 by sokon            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

int	ft_strcmp(char *s1, char *s2)
{
	int	i;
	int	n;
	int	p;

	i = 0;
	n = 0;
	while (s1[i] != '\0' || s2[i] != '\0')
	{
		if (s1[i] == s2[i])
		{
			i++;
		}
		else if ((s1[i] == '\0' && s2[i] != '\0')
			|| (s1[i] != '\0' && s2[i] == '\0') || s1[i] != s2[i])
		{
			n = 1;
			p = s1[i] - s2[i];
			return (p);
		}
	}
	if (n == 0)
	{
		return (n);
	}
	return (n);
}

// int	main()
// {
// 	char	str[] = "adb";
// 	char	src[] = "adbge";
// 	int	res;

// 	res = ft_strcmp(str,src);
// 	printf("%d", res);
// }