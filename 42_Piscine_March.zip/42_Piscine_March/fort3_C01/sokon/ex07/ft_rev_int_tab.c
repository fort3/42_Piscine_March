/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_rev_int_tab.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sokon <sokon@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024-03-01 21:59:38 by sokon             #+#    #+#             */
/*   Updated: 2024-03-01 22:56:29 by sokon            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <stdlib.h>

void	ft_rev_int_tab(int *tab, int size)
{
	int	num;
	int	i;

	i = 0;
	while (i < size / 2)
	{
		num = tab[i];
		tab[i] = tab[size - i - 1];
		tab[size - i - 1] = num;
		i++;
	}
}
