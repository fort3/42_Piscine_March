/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strdup.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sokon <sokon@student.42.fr>                #+#  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024-03-13 22:52:19 by sokon             #+#    #+#             */
/*   Updated: 2024-03-13 22:52:19 by sokon            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <stdlib.h>

char	*ft_strdup(char *src)
{
	int		i;
	char	*dup;
	char	*pnt;

	i = 0;
	while (src[i] != '\0')
	{
		i++;
	}
	dup = malloc(i + 1);
	pnt = dup;
	if (pnt == NULL)
		return ((char *) NULL);
	i = 0;
	while (src[i] != '\0')
	{
		pnt[i] = src[i];
		i++;
	}
	pnt[i] = '\0';
	return (pnt);
}

// int main()
// {
// 	char src[] = "heya42";
// 	printf("%s",ft_strdup(src));
// }