/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strjoin.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sokon <sokon@student.42.fr>                #+#  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024-03-16 19:57:21 by sokon             #+#    #+#             */
/*   Updated: 2024-03-16 19:57:21 by sokon            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <stdlib.h>

char	*ft_strcat(char *dest, char *src);
int		ft_sep_len(char *str);
int		ft_strlen(char **str, int size);

char	*ft_strjoin(int size, char **strs, char *sep)
{
	int		f_length;
	char	*concat;
	int		i;

	if (!size)
	{
		concat = (char *)malloc(sizeof(char));
		return (concat);
	}
	else
	{
		f_length = ft_strlen(strs, size) + (ft_sep_len(sep) * (size + 1));
		concat = (char *)malloc(sizeof(char) * (f_length + 1));
		if (!concat)
			return (0);
	}
	i = -1;
	*concat = 0;
	while (++i < size)
	{
		concat = ft_strcat(concat, strs[i]);
		if (i + 1 != size)
			ft_strcat(concat, sep);
	}
	return ((ft_strcat(concat, "\0")));
}

int	ft_sep_len(char *str)
{
	int	i;
	int	j;

	i = -1;
	j = 0;
	while (str[++i])
	{
		j++;
	}
	return (j);
}

int	ft_strlen(char **str, int size)
{
	int	i;
	int	j;
	int	real_len;

	i = -1;
	real_len = 0;
	while (++i < size)
	{
		j = -1;
		while (str[i][++j] != '\0')
		{
			real_len++;
		}
	}
	return (real_len);
}

char	*ft_strcat(char *dest, char *src)
{
	int	i;
	int	j;

	i = 0;
	j = 0;
	while (dest[i] != '\0')
	{
		i++;
	}
	while (src[j] != '\0')
	{
		dest[i + j] = src[j];
		j++;
	}
	dest[i + j] = '\0';
	return (dest);
}

// int main()
// {
// 	int size;
// 	char **strs;
// 	char *sep;

// 	strs = (char *[]){"Hello","World"};
// 	sep = "/";
// 	size = 2;
// 	char *a =  ft_strjoin(size, strs, sep);
// 	printf("%s", a);
// 	free(a);
// }