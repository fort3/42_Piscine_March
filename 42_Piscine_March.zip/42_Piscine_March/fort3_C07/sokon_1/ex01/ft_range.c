/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strndup.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sokon <sokon@student.42.fr>                #+#  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024-03-16 17:40:54 by sokon             #+#    #+#             */
/*   Updated: 2024-03-16 17:40:54 by sokon            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include <stdio.h>

int	*ft_range(int min, int max)
{
	int	i;
	int	j;
	int	*arr;

	if (min >= max)
		return (NULL);
	i = max - min + 1;
	j = 0;
	arr = (int *)malloc(sizeof(int) * i);
	while (min < max)
		arr[j++] = min++;
	return (arr);
}

// int main()
// {
// 	int	min;
// 	int max;
// 	int ran;
// 	int i;
// 	int *arr_called_p;

// 	i = 0;
// 	min = 2;
// 	max = -5;
// 	ran = max - min;
// 	arr_called_p = ft_range(min,max);

// 	while( i < ran)
// 	{
// 		printf("%d",arr_called_p[i]);
// 		i++;
// 	}
// }