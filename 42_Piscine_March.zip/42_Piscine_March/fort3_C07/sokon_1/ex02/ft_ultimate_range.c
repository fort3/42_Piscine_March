/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ultimate_range.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sokon <sokon@student.42.fr>                #+#  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024-03-16 19:09:49 by sokon             #+#    #+#             */
/*   Updated: 2024-03-16 19:09:49 by sokon            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include <stdio.h>

int	ft_ultimate_range(int **range, int min, int max)
{
	int	i;
	int	j;
	int	*arr;

	if (min >= max)
	{
		*range = NULL;
		return (0);
	}
	i = max - min + 1;
	j = 0;
	arr = (int *)malloc(sizeof(int) * i);
	if (arr == 0)
		return (-1);
	while (min < max)
		arr[j++] = min++;
	*range = arr;
	return (j);
}

// int main()
// {
// 	int	min;
// 	int max;
// 	int **ran;
// 	int arr_called_p;

// 	min = -2;
// 	max = 5;
// 	ran = (int *[]){&min,&max};
// 	arr_called_p = ft_ultimate_range(ran,min,max);

// 	printf("%d",arr_called_p);
// }