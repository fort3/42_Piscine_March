/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_sqrt.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sokon <sokon@student.42.fr>                #+#  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024-03-12 18:46:37 by sokon             #+#    #+#             */
/*   Updated: 2024-03-12 18:46:37 by sokon            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

int	ft_sqrt(int nb)
{
	int	sqrt;
	int	tmp;
	int	i;

	sqrt = nb / 2;
	tmp = 0;
	i = 0;
	if (nb == 1)
		return (1);
	if (nb == 2 || nb <= 0)
		return (0);
	while (i * i <= nb && i < 46341)
	{
		tmp = sqrt;
		sqrt = (nb / sqrt + tmp) / 2;
		i--;
	}
	if (nb % 1 == 0)
		return (sqrt);
	else
		return (0);
}

// int main()
// {
// 	printf("%d",ft_sqrt(25));
// }