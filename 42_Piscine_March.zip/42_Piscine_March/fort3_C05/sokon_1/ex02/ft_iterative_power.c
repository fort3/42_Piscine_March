/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_iterative_power.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sokon <sokon@student.42.fr>                #+#  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024-03-11 17:49:20 by sokon             #+#    #+#             */
/*   Updated: 2024-03-11 17:49:20 by sokon            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

int	ft_iterative_power(int nb, int power)
{
	int	i;
	int	fact;

	fact = 1;
	i = 0;
	if (power < 0)
	{
		return (0);
	}
	while (i < power)
	{
		fact *= nb;
		i++;
	}
	return (fact);
}

// int main()
// {
//     int num = 5;
// 	int pow = 2;
//     printf("power %d of %d is %d", pow,num, ft_iterative_power(num, pow));
//    // return (0);
// }