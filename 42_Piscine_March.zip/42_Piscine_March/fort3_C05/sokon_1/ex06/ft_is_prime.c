/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_is_prime.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sokon <sokon@student.42.fr>                #+#  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024-03-12 18:59:27 by sokon             #+#    #+#             */
/*   Updated: 2024-03-12 18:59:27 by sokon            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

int	ft_is_prime(int nb)
{
	int	pr_num;
	int	i;

	i = 2;
	pr_num = 1;
	if (nb <= 0 || nb == 1)
		return (0);
	while (i <= nb / 2)
	{
		if (nb % i == 0)
		{
			pr_num = 0;
			break ;
		}
		i++;
	}
	if (pr_num)
		return (pr_num);
	else
		return (0);
}

// int main()
// {
// 	printf("%d",ft_is_prime(25));
// }