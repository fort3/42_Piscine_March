/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_recursive_factorial.c                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sokon <sokon@student.42.fr>                #+#  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024-03-11 17:39:56 by sokon             #+#    #+#             */
/*   Updated: 2024-03-11 17:39:56 by sokon            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

int	ft_recursive_factorial(int nb)
{
	int					i;
	unsigned long long	fact;

	fact = 1;
	i = 1;
	if (nb < 0)
	{
		return (0);
	}
	if (i <= nb)
	{
		fact = nb * ft_recursive_factorial(nb - 1);
	}
	return (fact);
}

// int main()
// {
//     int num = 5;
//     printf("Factorial of %d is %d", num, ft_recursive_factorial(num));
//    // return (0);
// }