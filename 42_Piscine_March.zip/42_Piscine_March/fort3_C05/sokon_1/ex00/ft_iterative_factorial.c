/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_iterative_factorial.c                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sokon <sokon@student.42.fr>                #+#  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024-03-09 16:52:35 by sokon             #+#    #+#             */
/*   Updated: 2024-03-09 16:52:35 by sokon            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

int	ft_iterative_factorial(int nb)
{
	int					i;
	unsigned long long	fact;

	fact = 1;
	i = 1;
	if (nb < 0)
	{
		return (0);
	}
	while (i <= nb)
	{
		fact *= i;
		i++;
	}
	return (fact);
}

// int main()
// {
//     int num = 5;
//     printf("Factorial of %d is %d", num, ft_iterative_factorial(num));
//    // return (0);
// }