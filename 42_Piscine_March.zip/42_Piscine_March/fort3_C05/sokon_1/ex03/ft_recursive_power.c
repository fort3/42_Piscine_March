/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_recursive_power.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sokon <sokon@student.42.fr>                #+#  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024-03-11 18:09:14 by sokon             #+#    #+#             */
/*   Updated: 2024-03-11 18:09:14 by sokon            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

int	ft_recursive_power(int nb, int power)
{
	int	fact;

	fact = 1;
	if (power < 0)
	{
		return (0);
	}
	if (power != 0)
	{
		fact = nb * ft_recursive_power(nb, power - 1);
	}
	return (fact);
}

// int main()
// {
//     int num = 5;
// 				int pow = 2;
//     printf("power %d of %d is %d", pow,num, ft_recursive_power(num, pow));
//    // return (0);
// }