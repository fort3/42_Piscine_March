/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_numeric.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sokon <sokon@student.42.fr>                #+#  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024-03-04 14:46:32 by sokon             #+#    #+#             */
/*   Updated: 2024-03-04 14:46:32 by sokon            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

int	ft_str_is_numeric(char *src)
{
	int	i;

	i = 0;
	while (src[i] >= 48 && src[i] <= 57)
	{
		i++;
	}
	if (src[i] == '\0')
	{
		return (1);
	}
	else
	{
		return (0);
	}
}

// int main(void)
// {
// 	char str[] = "12313";
// 	int res;

// 	res = ft_str_is_numeric(str);
// 	printf("%d\n", res);

// }