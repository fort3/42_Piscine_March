/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcapitalize.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sokon <sokon@student.42.fr>                #+#  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024-03-05 16:01:17 by sokon             #+#    #+#             */
/*   Updated: 2024-03-05 16:01:17 by sokon            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

char	*ft_func_logic(char *str, int i);

char	*ft_strcapitalize(char *str)
{
	int	i;

	i = 0;
	ft_func_logic(str, i);
	return (str);
}

char	*ft_func_logic(char *str, int i)
{
	while (str[i])
	{
		if (i == 0 && ((str[i] >= 'a' && str[i] <= 'z') || (str[i] >= 'A'
					&& str[i] <= 'Z')) && (str[i] >= 'a' && str[i] <= 'z'))
		{
			str[i] -= 32;
		}
		else if ((str[i] < '0' || (str[i] > '9' && str[i] < 'A')
				|| (str[i] > 'Z' && str[i] < 'a') || str[i] > 'z')
			&& ((str[i + 1] >= 'a' && str[i + 1] <= 'z')
				|| (str[i + 1] >= 'A' && str[i + 1] <= 'Z')))
		{
			if (str[i + 1] >= 'a' && str[i + 1] <= 'z')
			{
				str[i + 1] -= 32;
			}
		}
		else if (str[i + 1] >= 'A' && str[i + 1] <= 'Z')
		{
			str[i + 1] += 32;
		}
		i++;
	}
	return (str);
}
